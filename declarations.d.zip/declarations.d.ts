declare module "* .jpg";
declare module "* .gif";
declare module "* .png";