export default interface ImageCategory {
  category: string,
  images: string[],
}
