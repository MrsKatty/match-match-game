import Component from "../components/Component";

export default interface ComponentOptions {
  rootElement: string,
  nestedElements: Component[]
}
