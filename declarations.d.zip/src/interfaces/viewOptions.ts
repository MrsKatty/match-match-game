import Component from "../components/Component";

export default interface viewOptions {
  components: Component[],
}
